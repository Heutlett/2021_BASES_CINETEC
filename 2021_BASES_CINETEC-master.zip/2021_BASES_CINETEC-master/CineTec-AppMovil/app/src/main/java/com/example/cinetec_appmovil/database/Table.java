package com.example.cinetec_appmovil.database;

public enum Table {
    ALL, BRANCHES, PROJECTIONS, CLIENTS, MOVIES
}
