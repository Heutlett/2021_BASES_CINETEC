export interface Projection{
    room_id:number;
    movie_id:number;
    id:number;
    date:string;
    schedule:string;
}