export interface Actor{
    id:number;
    name:string;
}