export interface Projections{
    schedule: string[];
    id:number;
    name:string;
    time:string[];
    actors:string[];
    director:string,
    classification:string;
    price:number;
    room:number;
    image:string;
    projection_ids:number[];
    room_ids:number[];

}