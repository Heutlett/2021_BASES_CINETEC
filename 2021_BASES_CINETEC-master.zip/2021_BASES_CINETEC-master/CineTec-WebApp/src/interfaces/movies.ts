export interface Movie{
    id:number;
    code:string;
    director_id:number;
    image:string;
    original_name:string;
    name:string;
    length:string;
    director:string;
    actors:string[];
}