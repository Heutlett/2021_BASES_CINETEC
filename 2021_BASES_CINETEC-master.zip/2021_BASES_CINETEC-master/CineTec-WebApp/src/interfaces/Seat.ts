export interface Seat{
    number:number;
    projection_id:number;
    status:string;
}