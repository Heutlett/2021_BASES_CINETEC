export interface Room{
    branch_name:string;
    id:number;
    row_quantity:number;
    column_quantity:number;
    capacity:number;
}