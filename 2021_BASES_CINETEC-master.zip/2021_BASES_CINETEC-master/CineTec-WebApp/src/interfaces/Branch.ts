export interface Branch{
    cinema_name:string;
    province:string;
    district:string;
}