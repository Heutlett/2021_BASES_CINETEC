export interface Employee{
    branch_id:string;
    cedula:number;
    first_name:string;
    middle_name:string;
    first_surname:string;
    second_surname:string;
    birth_date:string;
    start_date:string;
    phone_number:string;
    username:string;
    password:string;
}