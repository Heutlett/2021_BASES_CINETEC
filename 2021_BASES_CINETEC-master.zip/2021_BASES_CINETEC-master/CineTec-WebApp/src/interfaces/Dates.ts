export interface Dates{
    dates:string[];
}