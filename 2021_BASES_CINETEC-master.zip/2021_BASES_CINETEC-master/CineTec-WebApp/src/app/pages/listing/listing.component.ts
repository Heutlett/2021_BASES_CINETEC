import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listing',
  templateUrl: './listing.component.html',
  styleUrls: ['./listing.component.css']
})

/**
 * Pagina que muestra las proyecciones para una sucursal y dia especificos
 */
export class ListingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
