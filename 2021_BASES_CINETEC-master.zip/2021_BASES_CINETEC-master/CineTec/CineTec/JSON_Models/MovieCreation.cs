﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CineTec.JSON_Models
{
    public class MovieCreation
    {

        public string[] actors { get; set; }
        public string classification_id { get; set; }
        public string director { get; set; }
        public string image { get; set; }
        public string original_name { get; set; }
        public string name { get; set; }
        public string length { get; set; }



    }
}
